create
    definer = root@`%` function getRegionChildrenList(regionCode varchar(40)) returns varchar(8000)
BEGIN
    #Routine body goes here...
    DECLARE sChildList VARCHAR(8000);
    DECLARE sChildTemp VARCHAR(8000);
    DECLARE rootId varchar(40) default '';

    DECLARE sChildCodeList VARCHAR(8000);
    SET rootId =(SELECT tx_id FROM sys_region WHERE region_code = regionCode);

    SET sChildTemp =cast(rootId as CHAR);

    SET SESSION group_concat_max_len = 102400;

    WHILE sChildTemp is not null DO
            IF (sChildList is not null) THEN
                SET sChildList = concat(sChildList,',',sChildTemp);
            ELSE
                SET sChildList = concat(sChildTemp);
            END IF;
            SELECT group_concat(tx_id) INTO sChildTemp FROM sys_region where FIND_IN_SET(tx_pid,sChildTemp)>0;
        END WHILE;

    SELECT group_concat(region_code) INTO sChildCodeList FROM sys_region where FIND_IN_SET(tx_id,sChildList)>0;

    RETURN sChildCodeList;

END;

