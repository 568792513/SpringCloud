create
    definer = root@`%` function getRegionParentList(regionCode varchar(40)) returns varchar(1000)
BEGIN
    DECLARE fid varchar(40) default '';
    DECLARE rootId varchar(40) default '';
    DECLARE str varchar(1000) default regionCode;
    DECLARE r_code varchar(1000) default '';


    SET rootId =(SELECT id FROM sys_region WHERE region_code = regionCode);


    WHILE rootId != '0'  do
            SET fid =(SELECT parent_id FROM sys_region WHERE id = rootId);
            SET r_code =(SELECT region_code FROM sys_region WHERE id = fid);
            IF fid != '0' THEN
                SET str = concat(str, ',', r_code);
                SET rootId = fid;
            ELSE
                SET rootId = fid;
            END IF;
        END WHILE;
    return str;
END;

