create
    definer = root@`%` function getOrgChildrenList(rootId varchar(40)) returns varchar(8000)
BEGIN
    #Routine body goes here...

    DECLARE sChildList VARCHAR(8000);
    DECLARE sChildTemp VARCHAR(8000);
    SET sChildTemp =cast(rootId as CHAR);

    SET SESSION group_concat_max_len = 102400;

    WHILE sChildTemp is not null DO
            IF (sChildList is not null) THEN
                SET sChildList = concat(sChildList,',',sChildTemp);
            ELSE
                SET sChildList = concat(sChildTemp);
            END IF;
            SELECT group_concat(id) INTO sChildTemp FROM sys_org where is_enabled = 1 and FIND_IN_SET(parent_id,sChildTemp)>0;
        END WHILE;

    RETURN sChildList;

END;

