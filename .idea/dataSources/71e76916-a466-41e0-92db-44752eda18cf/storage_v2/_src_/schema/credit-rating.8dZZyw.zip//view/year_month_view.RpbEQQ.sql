create definer = root@`%` view year_month_view as
select date_format(curdate(), '%Y-%m') AS `year_month`
union
select date_format((curdate() - interval 1 month), '%Y-%m') AS `year_month`
union
select date_format((curdate() - interval 2 month), '%Y-%m') AS `year_month`
union
select date_format((curdate() - interval 3 month), '%Y-%m') AS `year_month`
union
select date_format((curdate() - interval 4 month), '%Y-%m') AS `year_month`
union
select date_format((curdate() - interval 5 month), '%Y-%m') AS `year_month`
union
select date_format((curdate() - interval 6 month), '%Y-%m') AS `year_month`
union
select date_format((curdate() - interval 7 month), '%Y-%m') AS `year_month`
union
select date_format((curdate() - interval 8 month), '%Y-%m') AS `year_month`
union
select date_format((curdate() - interval 9 month), '%Y-%m') AS `year_month`
union
select date_format((curdate() - interval 10 month), '%Y-%m') AS `year_month`
union
select date_format((curdate() - interval 11 month), '%Y-%m') AS `year_month`;

